var r=(e=>(e.Refresh="refresh",e.Close="close",e))(r||{});export{r as T};
