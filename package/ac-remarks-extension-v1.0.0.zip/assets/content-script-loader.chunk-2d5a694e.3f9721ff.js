(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-2d5a694e.js")
    );
  })().catch(console.error);

})();
