(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-b2a6404b.js")
    );
  })().catch(console.error);

})();
