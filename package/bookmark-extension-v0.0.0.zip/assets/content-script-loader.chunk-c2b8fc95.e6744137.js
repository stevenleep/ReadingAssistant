(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-c2b8fc95.js")
    );
  })().catch(console.error);

})();
