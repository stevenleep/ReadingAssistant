(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-aa312a0f.js")
    );
  })().catch(console.error);

})();
